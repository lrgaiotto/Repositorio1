#include <stdio.h>
#include <unistd.h>

int main(){

	int a,b,operacao,memoria=0,resultado;
	char sair;	

	while(sair!='S' && sair!='s'){

	system("clear");

	printf("\n--------------calculadora--------------");
	
	
	printf("\nDigite o número: ");
	scanf("%d", &a);	
	
	printf("\n---------------------------------------\n");
	printf("1 - Soma 			      |\n");
	printf("2 - Subtração			      |\n");
	printf("3 - Multiplicão			      |\n");
	printf("4 - Divisão 			      |\n");
	printf("5 - M+ (Memorizar número) 	      |\n");
	printf("6 - M- (Subtrair de número memorizado)|\n");		
	printf("7 - MR (Exibir número memorizado)     |\n");
	printf("8 - MC (Limpar número memorizado)     |\n");
	printf("9 - Sair 			      |\n");	
	printf("--------------------------------------\n");
	printf("--- ");
	scanf("%d", &operacao);
	
	switch(operacao){

	case 1:

		printf("\nDigite o segundo número: ");
		scanf("%d", &b);

		resultado = a + b;

		printf("\nResultado: %d\n", resultado);
		
		printf("\nSair? S/N - ");
		scanf("%s", &sair);

		break;

	case 2:

		printf("\nDigite o segundo número: ");
		scanf("%d", &b);

		resultado = a - b;

		printf("\nResultado: %d\n", resultado);
		
		printf("\nSair? S/N - ");
		scanf("%s", &sair);

		break;

	case 3:

		printf("\nDigite o segundo número: ");
		scanf("%d", &b);

		resultado = a * b;

		printf("\nResultado: %d\n", resultado);
		
		printf("\nSair? S/N - ");
		scanf("%s", &sair);

		break;

	case 4:
		printf("\nDigite o segundo número: ");
		scanf("%d", &b);

		resultado = a / b;

		printf("\nResultado: %d\n", resultado);
		
		printf("\nSair? S/N - ");
		scanf("%s", &sair);
		
		break;

	case 5:
	
		memoria = a;
		
		printf("Memorizado! (%d)", memoria);

		break;

	case 6:

		resultado = a - memoria;

		printf("\nResultado: %d\n", resultado);
		
		printf("\nSair? S/N - ");
		scanf("%s", &sair);
	
		break;

	case 7:	

		printf("MEMÓRIA: %d", memoria);

		break;

	case 8:

		memoria = 0;

		break;

	case 9:

		sair = 's';

		break;

	default:

		printf("\nEntrada incorreta!");

		break;

	}


	}


	return 0;
}
